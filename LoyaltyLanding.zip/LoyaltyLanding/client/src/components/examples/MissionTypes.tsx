import MissionTypes from '../MissionTypes';

export default function MissionTypesExample() {
  return <MissionTypes />;
}
