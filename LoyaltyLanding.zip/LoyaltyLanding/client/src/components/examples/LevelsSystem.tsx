import LevelsSystem from '../LevelsSystem';

export default function LevelsSystemExample() {
  return <LevelsSystem />;
}
