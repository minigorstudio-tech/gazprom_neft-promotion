import Benefits from '../Benefits';

export default function BenefitsExample() {
  return <Benefits />;
}
